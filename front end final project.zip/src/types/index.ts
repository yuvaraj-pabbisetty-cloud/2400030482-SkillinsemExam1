export type UserRole = 'student' | 'employer' | 'officer' | 'admin';

export type JobStatus = 'pending' | 'verified' | 'rejected';

export interface User {
  id: string;
  email: string;
  password: string;
  name: string;
  role: UserRole;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  salary: string;
  description: string;
  location: string;
  qualifications: string;
  employerId: string;
  status: JobStatus;
  createdAt: Date;
}

export interface Application {
  id: string;
  studentId: string;
  jobId: string;
  appliedDate: Date;
}
