import React, { createContext, useContext, useState, useEffect } from 'react';
import { Job, Application, User } from '../types';

interface DataContextType {
  jobs: Job[];
  applications: Application[];
  users: User[];
  addJob: (job: Omit<Job, 'id' | 'createdAt'>) => void;
  updateJob: (id: string, updates: Partial<Job>) => void;
  deleteJob: (id: string) => void;
  addApplication: (studentId: string, jobId: string) => void;
  deleteUser: (userId: string) => void;
  updateUsers: (users: User[]) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within DataProvider');
  }
  return context;
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    // Load jobs from localStorage
    const storedJobs = localStorage.getItem('jobs');
    if (storedJobs) {
      const parsedJobs = JSON.parse(storedJobs);
      setJobs(parsedJobs.map((job: any) => ({
        ...job,
        createdAt: new Date(job.createdAt)
      })));
    } else {
      // Initialize with sample jobs
      const sampleJobs: Job[] = [
        {
          id: '1',
          title: 'Software Developer Intern',
          company: 'Tech Solutions Inc.',
          salary: '$3000/month',
          description: 'Looking for talented software development interns to join our team.',
          location: 'New York, NY',
          qualifications: 'Computer Science student, JavaScript, React',
          employerId: '4',
          status: 'verified',
          createdAt: new Date()
        },
        {
          id: '2',
          title: 'Marketing Assistant',
          company: 'Digital Marketing Co.',
          salary: '$2500/month',
          description: 'Support our marketing team with campaigns and social media.',
          location: 'Remote',
          qualifications: 'Marketing or Communications student',
          employerId: '4',
          status: 'verified',
          createdAt: new Date()
        },
        {
          id: '3',
          title: 'Data Analyst Intern',
          company: 'Analytics Corp',
          salary: '$3500/month',
          description: 'Work with data visualization and analysis tools.',
          location: 'San Francisco, CA',
          qualifications: 'Statistics or Computer Science, Python, SQL',
          employerId: '4',
          status: 'pending',
          createdAt: new Date()
        }
      ];
      setJobs(sampleJobs);
      localStorage.setItem('jobs', JSON.stringify(sampleJobs));
    }

    // Load applications from localStorage
    const storedApplications = localStorage.getItem('applications');
    if (storedApplications) {
      const parsedApplications = JSON.parse(storedApplications);
      setApplications(parsedApplications.map((app: any) => ({
        ...app,
        appliedDate: new Date(app.appliedDate)
      })));
    }

    // Load users from localStorage
    const storedUsers = localStorage.getItem('users');
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers));
    }
  }, []);

  const addJob = (job: Omit<Job, 'id' | 'createdAt'>) => {
    const newJob: Job = {
      ...job,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    const updatedJobs = [...jobs, newJob];
    setJobs(updatedJobs);
    localStorage.setItem('jobs', JSON.stringify(updatedJobs));
  };

  const updateJob = (id: string, updates: Partial<Job>) => {
    const updatedJobs = jobs.map(job => 
      job.id === id ? { ...job, ...updates } : job
    );
    setJobs(updatedJobs);
    localStorage.setItem('jobs', JSON.stringify(updatedJobs));
  };

  const deleteJob = (id: string) => {
    const updatedJobs = jobs.filter(job => job.id !== id);
    setJobs(updatedJobs);
    localStorage.setItem('jobs', JSON.stringify(updatedJobs));
  };

  const addApplication = (studentId: string, jobId: string) => {
    const newApplication: Application = {
      id: Date.now().toString(),
      studentId,
      jobId,
      appliedDate: new Date()
    };
    const updatedApplications = [...applications, newApplication];
    setApplications(updatedApplications);
    localStorage.setItem('applications', JSON.stringify(updatedApplications));
  };

  const deleteUser = (userId: string) => {
    const updatedUsers = users.filter(user => user.id !== userId);
    setUsers(updatedUsers);
    localStorage.setItem('users', JSON.stringify(updatedUsers));
  };

  const updateUsers = (newUsers: User[]) => {
    setUsers(newUsers);
    localStorage.setItem('users', JSON.stringify(newUsers));
  };

  return (
    <DataContext.Provider value={{
      jobs,
      applications,
      users,
      addJob,
      updateJob,
      deleteJob,
      addApplication,
      deleteUser,
      updateUsers
    }}>
      {children}
    </DataContext.Provider>
  );
};
