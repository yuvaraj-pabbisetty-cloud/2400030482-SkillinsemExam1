import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { AuthForm } from './components/AuthForm';
import { StudentDashboard } from './components/StudentDashboard';
import { EmployerDashboard } from './components/EmployerDashboard';
import { PlacementOfficerDashboard } from './components/PlacementOfficerDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { Toaster } from './components/ui/sonner';

function AppContent() {
  const { currentUser } = useAuth();
  const [currentView, setCurrentView] = useState<string>('home');

  const handleNavigate = (view: string) => {
    setCurrentView(view);
  };

  const handleAuthSuccess = () => {
    setCurrentView('dashboard');
  };

  const renderContent = () => {
    // If user is logged in and navigates to dashboard
    if (currentView === 'dashboard' && currentUser) {
      switch (currentUser.role) {
        case 'student':
          return <StudentDashboard />;
        case 'employer':
          return <EmployerDashboard />;
        case 'officer':
          return <PlacementOfficerDashboard />;
        case 'admin':
          return <AdminDashboard />;
        default:
          return <HomePage />;
      }
    }

    // Handle other views
    switch (currentView) {
      case 'login':
        return (
          <AuthForm
            mode="login"
            onSuccess={handleAuthSuccess}
            onToggleMode={() => setCurrentView('register')}
          />
        );
      case 'register':
        return (
          <AuthForm
            mode="register"
            onSuccess={handleAuthSuccess}
            onToggleMode={() => setCurrentView('login')}
          />
        );
      case 'home':
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar onNavigate={handleNavigate} currentView={currentView} />
      {renderContent()}
      <Toaster />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </AuthProvider>
  );
}
