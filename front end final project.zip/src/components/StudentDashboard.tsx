import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { JobCard } from './JobCard';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Briefcase, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export const StudentDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const { jobs, applications, addApplication } = useData();
  const [activeTab, setActiveTab] = useState('all-jobs');

  const verifiedJobs = jobs.filter(job => job.status === 'verified');
  const myApplications = applications.filter(app => app.studentId === currentUser?.id);
  const appliedJobIds = new Set(myApplications.map(app => app.jobId));

  const handleApply = (jobId: string) => {
    if (currentUser) {
      addApplication(currentUser.id, jobId);
      toast.success('Application submitted successfully!');
    }
  };

  const appliedJobs = verifiedJobs.filter(job => appliedJobIds.has(job.id));

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-2">Student Dashboard</h1>
        <p className="text-muted-foreground">Browse and apply for available job opportunities</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Available Jobs</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{verifiedJobs.length}</div>
            <p className="text-xs text-muted-foreground">
              Active job listings
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>My Applications</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{myApplications.length}</div>
            <p className="text-xs text-muted-foreground">
              Jobs applied for
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Jobs Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="all-jobs">All Jobs</TabsTrigger>
          <TabsTrigger value="applied">Applied Jobs</TabsTrigger>
        </TabsList>

        <TabsContent value="all-jobs" className="mt-6">
          {verifiedJobs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {verifiedJobs.map(job => (
                <JobCard
                  key={job.id}
                  job={job}
                  showActions="student"
                  onApply={handleApply}
                  isApplied={appliedJobIds.has(job.id)}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-muted-foreground">No verified jobs available at the moment.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="applied" className="mt-6">
          {appliedJobs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {appliedJobs.map(job => (
                <JobCard
                  key={job.id}
                  job={job}
                  showActions="student"
                  isApplied={true}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-muted-foreground">You haven't applied to any jobs yet.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};
