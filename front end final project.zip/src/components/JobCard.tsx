import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Job } from '../types';
import { MapPin, DollarSign, Pencil, Trash2 } from 'lucide-react';

interface JobCardProps {
  job: Job;
  showStatus?: boolean;
  onApply?: (jobId: string) => void;
  onEdit?: (job: Job) => void;
  onDelete?: (jobId: string) => void;
  onVerify?: (jobId: string) => void;
  onReject?: (jobId: string) => void;
  isApplied?: boolean;
  showActions?: 'student' | 'employer' | 'officer' | 'admin' | 'none';
}

export const JobCard: React.FC<JobCardProps> = ({
  job,
  showStatus = false,
  onApply,
  onEdit,
  onDelete,
  onVerify,
  onReject,
  isApplied = false,
  showActions = 'none'
}) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle>{job.title}</CardTitle>
            <CardDescription>{job.company}</CardDescription>
          </div>
          {showStatus && (
            <Badge 
              variant={
                job.status === 'verified' ? 'default' : 
                job.status === 'pending' ? 'secondary' : 
                'destructive'
              }
            >
              {job.status}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-muted-foreground">
          <DollarSign className="h-4 w-4" />
          <span>{job.salary}</span>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span>{job.location}</span>
        </div>
        <p className="text-muted-foreground">{job.description}</p>
        <div>
          <span className="text-sm">Qualifications: {job.qualifications}</span>
        </div>

        <div className="flex gap-2 pt-2">
          {showActions === 'student' && onApply && (
            <Button 
              onClick={() => onApply(job.id)}
              disabled={isApplied}
              className="w-full"
            >
              {isApplied ? 'Already Applied' : 'Apply Now'}
            </Button>
          )}

          {showActions === 'employer' && (
            <>
              {onEdit && (
                <Button 
                  variant="outline" 
                  onClick={() => onEdit(job)}
                  className="flex-1"
                >
                  <Pencil className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
              {onDelete && (
                <Button 
                  variant="destructive" 
                  onClick={() => onDelete(job.id)}
                  className="flex-1"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              )}
            </>
          )}

          {showActions === 'officer' && (
            <>
              {onVerify && job.status === 'pending' && (
                <Button 
                  onClick={() => onVerify(job.id)}
                  className="flex-1"
                >
                  Verify
                </Button>
              )}
              {onReject && job.status === 'pending' && (
                <Button 
                  variant="destructive" 
                  onClick={() => onReject(job.id)}
                  className="flex-1"
                >
                  Reject
                </Button>
              )}
            </>
          )}

          {showActions === 'admin' && onDelete && (
            <Button 
              variant="destructive" 
              onClick={() => onDelete(job.id)}
              className="w-full"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Job
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
