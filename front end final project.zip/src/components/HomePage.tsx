import React from 'react';
import { useData } from '../context/DataContext';
import { JobCard } from './JobCard';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Briefcase, Users, Building2 } from 'lucide-react';

export const HomePage: React.FC = () => {
  const { jobs } = useData();
  const verifiedJobs = jobs.filter(job => job.status === 'verified');
  const latestJobs = verifiedJobs.slice(-6).reverse();

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="mb-4">Student Job Portal</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Connect students with exciting job opportunities. Find your next internship or part-time position today!
        </p>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Available Jobs</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{verifiedJobs.length}</div>
            <p className="text-xs text-muted-foreground">
              Active job listings
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Top Companies</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">
              {new Set(verifiedJobs.map(j => j.company)).size}
            </div>
            <p className="text-xs text-muted-foreground">
              Hiring partners
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">Join Now</div>
            <p className="text-xs text-muted-foreground">
              Start your career journey
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Latest Jobs Section */}
      <div className="mb-8">
        <h2 className="mb-6">Latest Job Opportunities</h2>
        {latestJobs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestJobs.map(job => (
              <JobCard key={job.id} job={job} showActions="none" />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-muted-foreground">No jobs available at the moment. Check back soon!</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};
