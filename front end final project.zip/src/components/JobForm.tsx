import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { Job } from '../types';

interface JobFormProps {
  onSubmit: (job: Omit<Job, 'id' | 'createdAt' | 'employerId' | 'status'>) => void;
  onCancel: () => void;
  editingJob?: Job | null;
}

export const JobForm: React.FC<JobFormProps> = ({ onSubmit, onCancel, editingJob }) => {
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [salary, setSalary] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [qualifications, setQualifications] = useState('');

  useEffect(() => {
    if (editingJob) {
      setTitle(editingJob.title);
      setCompany(editingJob.company);
      setSalary(editingJob.salary);
      setDescription(editingJob.description);
      setLocation(editingJob.location);
      setQualifications(editingJob.qualifications);
    }
  }, [editingJob]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      title,
      company,
      salary,
      description,
      location,
      qualifications
    });
    
    // Reset form
    setTitle('');
    setCompany('');
    setSalary('');
    setDescription('');
    setLocation('');
    setQualifications('');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{editingJob ? 'Edit Job' : 'Post New Job'}</CardTitle>
        <CardDescription>
          {editingJob ? 'Update job details' : 'Fill in the job details below. Jobs will be verified by a Placement Officer before being visible to students.'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Job Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Software Developer Intern"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="company">Company Name</Label>
              <Input
                id="company"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="e.g. Tech Solutions Inc."
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="salary">Salary</Label>
              <Input
                id="salary"
                value={salary}
                onChange={(e) => setSalary(e.target.value)}
                placeholder="e.g. $3000/month"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. New York, NY or Remote"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Job Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the job role and responsibilities..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="qualifications">Required Qualifications</Label>
            <Textarea
              id="qualifications"
              value={qualifications}
              onChange={(e) => setQualifications(e.target.value)}
              placeholder="List the required qualifications and skills..."
              rows={3}
              required
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              {editingJob ? 'Update Job' : 'Post Job'}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};
