import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Users, Building2, Briefcase, Clock, Trash2, UserPlus } from 'lucide-react';
import { User, UserRole } from '../types';
import { toast } from 'sonner@2.0.3';

export const AdminDashboard: React.FC = () => {
  const { jobs, users: contextUsers, deleteJob, deleteUser, updateUsers } = useData();
  const [activeTab, setActiveTab] = useState('overview');
  const [users, setUsers] = useState<User[]>([]);
  const [newOfficerEmail, setNewOfficerEmail] = useState('');
  const [newOfficerName, setNewOfficerName] = useState('');
  const [newOfficerPassword, setNewOfficerPassword] = useState('');

  useEffect(() => {
    // Load users from localStorage
    const storedUsers = localStorage.getItem('users');
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers));
    }
  }, [contextUsers]);

  const students = users.filter(u => u.role === 'student');
  const employers = users.filter(u => u.role === 'employer');
  const officers = users.filter(u => u.role === 'officer');
  const verifiedJobs = jobs.filter(j => j.status === 'verified');
  const pendingJobs = jobs.filter(j => j.status === 'pending');

  const handleDeleteJob = (jobId: string) => {
    if (confirm('Are you sure you want to delete this job?')) {
      deleteJob(jobId);
      toast.success('Job deleted successfully!');
    }
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm('Are you sure you want to delete this user?')) {
      const updatedUsers = users.filter(u => u.id !== userId);
      setUsers(updatedUsers);
      updateUsers(updatedUsers);
      toast.success('User deleted successfully!');
    }
  };

  const handleAddOfficer = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newOfficerEmail || !newOfficerName || !newOfficerPassword) {
      toast.error('Please fill in all fields');
      return;
    }

    if (users.find(u => u.email === newOfficerEmail)) {
      toast.error('Email already exists');
      return;
    }

    const newOfficer: User = {
      id: Date.now().toString(),
      email: newOfficerEmail,
      password: newOfficerPassword,
      name: newOfficerName,
      role: 'officer'
    };

    const updatedUsers = [...users, newOfficer];
    setUsers(updatedUsers);
    updateUsers(updatedUsers);
    
    setNewOfficerEmail('');
    setNewOfficerName('');
    setNewOfficerPassword('');
    
    toast.success('Placement Officer added successfully!');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-2">Admin Dashboard</h1>
        <p className="text-muted-foreground">Full system control and management</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 max-w-2xl">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="jobs">Jobs</TabsTrigger>
          <TabsTrigger value="officers">Officers</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>Total Students</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl">{students.length}</div>
                <p className="text-xs text-muted-foreground">
                  Registered students
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>Total Employers</CardTitle>
                <Building2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl">{employers.length}</div>
                <p className="text-xs text-muted-foreground">
                  Active employers
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>Verified Jobs</CardTitle>
                <Briefcase className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl">{verifiedJobs.length}</div>
                <p className="text-xs text-muted-foreground">
                  Active listings
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>Pending Jobs</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl">{pendingJobs.length}</div>
                <p className="text-xs text-muted-foreground">
                  Awaiting review
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>System Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Total Users:</span>
                    <span>{users.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Placement Officers:</span>
                    <span>{officers.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Jobs:</span>
                    <span>{jobs.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Rejected Jobs:</span>
                    <span>{jobs.filter(j => j.status === 'rejected').length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.filter(u => u.role !== 'admin').map(user => (
                    <TableRow key={user.id}>
                      <TableCell>{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={
                          user.role === 'student' ? 'default' :
                          user.role === 'employer' ? 'secondary' :
                          'outline'
                        }>
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteUser(user.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="jobs" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Job Management</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {jobs.map(job => (
                    <TableRow key={job.id}>
                      <TableCell>{job.title}</TableCell>
                      <TableCell>{job.company}</TableCell>
                      <TableCell>
                        <Badge variant={
                          job.status === 'verified' ? 'default' :
                          job.status === 'pending' ? 'secondary' :
                          'destructive'
                        }>
                          {job.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteJob(job.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="officers" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Add Placement Officer</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddOfficer} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="officer-name">Full Name</Label>
                    <Input
                      id="officer-name"
                      value={newOfficerName}
                      onChange={(e) => setNewOfficerName(e.target.value)}
                      placeholder="Officer Name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="officer-email">Email</Label>
                    <Input
                      id="officer-email"
                      type="email"
                      value={newOfficerEmail}
                      onChange={(e) => setNewOfficerEmail(e.target.value)}
                      placeholder="officer@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="officer-password">Password</Label>
                    <Input
                      id="officer-password"
                      type="password"
                      value={newOfficerPassword}
                      onChange={(e) => setNewOfficerPassword(e.target.value)}
                      placeholder="••••••••"
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add Officer
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Current Officers</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {officers.map(officer => (
                      <TableRow key={officer.id}>
                        <TableCell>{officer.name}</TableCell>
                        <TableCell>{officer.email}</TableCell>
                        <TableCell>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteUser(officer.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
