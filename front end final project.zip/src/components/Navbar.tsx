import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Button } from './ui/button';
import { LogOut, Briefcase } from 'lucide-react';

interface NavbarProps {
  onNavigate: (view: string) => void;
  currentView: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentView }) => {
  const { currentUser, logout } = useAuth();

  const handleLogout = () => {
    logout();
    onNavigate('home');
  };

  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <Briefcase className="h-6 w-6" />
            <span>Student Job Portal</span>
          </div>
          
          <div className="flex items-center gap-4">
            {!currentUser ? (
              <>
                <Button 
                  variant="ghost" 
                  className="text-white hover:bg-blue-700"
                  onClick={() => onNavigate('home')}
                >
                  Home
                </Button>
                <Button 
                  variant="ghost" 
                  className="text-white hover:bg-blue-700"
                  onClick={() => onNavigate('login')}
                >
                  Login
                </Button>
                <Button 
                  variant="secondary"
                  onClick={() => onNavigate('register')}
                >
                  Register
                </Button>
              </>
            ) : (
              <>
                <span>Welcome, {currentUser.name}</span>
                <Button 
                  variant="ghost" 
                  className="text-white hover:bg-blue-700"
                  onClick={() => onNavigate('dashboard')}
                >
                  Dashboard
                </Button>
                <Button 
                  variant="ghost" 
                  className="text-white hover:bg-blue-700"
                  onClick={handleLogout}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};
