import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { JobCard } from './JobCard';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Briefcase, Clock, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export const PlacementOfficerDashboard: React.FC = () => {
  const { jobs, updateJob } = useData();
  const [activeTab, setActiveTab] = useState('pending');

  const pendingJobs = jobs.filter(job => job.status === 'pending');
  const verifiedJobs = jobs.filter(job => job.status === 'verified');
  const rejectedJobs = jobs.filter(job => job.status === 'rejected');

  const handleVerify = (jobId: string) => {
    updateJob(jobId, { status: 'verified' });
    toast.success('Job verified successfully!');
  };

  const handleReject = (jobId: string) => {
    if (confirm('Are you sure you want to reject this job posting?')) {
      updateJob(jobId, { status: 'rejected' });
      toast.success('Job rejected.');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-2">Placement Officer Dashboard</h1>
        <p className="text-muted-foreground">Review and verify job postings</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Pending Jobs</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{pendingJobs.length}</div>
            <p className="text-xs text-muted-foreground">
              Awaiting review
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Verified Jobs</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{verifiedJobs.length}</div>
            <p className="text-xs text-muted-foreground">
              Active listings
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Total Jobs</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{jobs.length}</div>
            <p className="text-xs text-muted-foreground">
              All submissions
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Jobs Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 max-w-lg">
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="verified">Verified</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-6">
          {pendingJobs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pendingJobs.map(job => (
                <JobCard
                  key={job.id}
                  job={job}
                  showStatus={true}
                  showActions="officer"
                  onVerify={handleVerify}
                  onReject={handleReject}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-muted-foreground">No pending jobs to review.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="verified" className="mt-6">
          {verifiedJobs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {verifiedJobs.map(job => (
                <JobCard
                  key={job.id}
                  job={job}
                  showStatus={true}
                  showActions="none"
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-muted-foreground">No verified jobs yet.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="rejected" className="mt-6">
          {rejectedJobs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {rejectedJobs.map(job => (
                <JobCard
                  key={job.id}
                  job={job}
                  showStatus={true}
                  showActions="none"
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-muted-foreground">No rejected jobs.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};
