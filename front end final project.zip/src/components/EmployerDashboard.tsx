import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { JobCard } from './JobCard';
import { JobForm } from './JobForm';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Briefcase, Clock, CheckCircle, Plus } from 'lucide-react';
import { Job } from '../types';
import { toast } from 'sonner@2.0.3';

export const EmployerDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const { jobs, addJob, updateJob, deleteJob } = useData();
  const [showForm, setShowForm] = useState(false);
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [activeTab, setActiveTab] = useState('all');

  const myJobs = jobs.filter(job => job.employerId === currentUser?.id);
  const pendingJobs = myJobs.filter(job => job.status === 'pending');
  const verifiedJobs = myJobs.filter(job => job.status === 'verified');
  const rejectedJobs = myJobs.filter(job => job.status === 'rejected');

  const handleSubmit = (jobData: Omit<Job, 'id' | 'createdAt' | 'employerId' | 'status'>) => {
    if (currentUser) {
      if (editingJob) {
        updateJob(editingJob.id, jobData);
        toast.success('Job updated successfully!');
        setEditingJob(null);
      } else {
        addJob({
          ...jobData,
          employerId: currentUser.id,
          status: 'pending'
        });
        toast.success('Job posted successfully! Awaiting verification.');
      }
      setShowForm(false);
    }
  };

  const handleEdit = (job: Job) => {
    setEditingJob(job);
    setShowForm(true);
  };

  const handleDelete = (jobId: string) => {
    if (confirm('Are you sure you want to delete this job?')) {
      deleteJob(jobId);
      toast.success('Job deleted successfully!');
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingJob(null);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="mb-2">Employer Dashboard</h1>
          <p className="text-muted-foreground">Manage your job postings</p>
        </div>
        {!showForm && (
          <Button onClick={() => setShowForm(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Post New Job
          </Button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Total Jobs</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{myJobs.length}</div>
            <p className="text-xs text-muted-foreground">
              All job postings
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Pending</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{pendingJobs.length}</div>
            <p className="text-xs text-muted-foreground">
              Awaiting verification
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Verified</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{verifiedJobs.length}</div>
            <p className="text-xs text-muted-foreground">
              Active listings
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Job Form */}
      {showForm && (
        <div className="mb-8">
          <JobForm
            onSubmit={handleSubmit}
            onCancel={handleCancel}
            editingJob={editingJob}
          />
        </div>
      )}

      {/* Jobs List */}
      {!showForm && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 max-w-2xl">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="verified">Verified</TabsTrigger>
            <TabsTrigger value="rejected">Rejected</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            {myJobs.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {myJobs.map(job => (
                  <JobCard
                    key={job.id}
                    job={job}
                    showStatus={true}
                    showActions="employer"
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">No jobs posted yet. Click "Post New Job" to get started.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="pending" className="mt-6">
            {pendingJobs.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pendingJobs.map(job => (
                  <JobCard
                    key={job.id}
                    job={job}
                    showStatus={true}
                    showActions="employer"
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">No pending jobs.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="verified" className="mt-6">
            {verifiedJobs.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {verifiedJobs.map(job => (
                  <JobCard
                    key={job.id}
                    job={job}
                    showStatus={true}
                    showActions="employer"
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">No verified jobs yet.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="rejected" className="mt-6">
            {rejectedJobs.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {rejectedJobs.map(job => (
                  <JobCard
                    key={job.id}
                    job={job}
                    showStatus={true}
                    showActions="employer"
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">No rejected jobs.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
};
